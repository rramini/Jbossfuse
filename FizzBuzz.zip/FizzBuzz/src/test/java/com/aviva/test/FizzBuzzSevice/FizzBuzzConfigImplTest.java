package com.aviva.test.FizzBuzzSevice;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import com.aviva.rest.FizzBuzzSevice.FizzBuzzConfigImpl;

@RunWith(MockitoJUnitRunner.class)
public class FizzBuzzConfigImplTest {

	
	@InjectMocks
	private FizzBuzzConfigImpl fizzBuzzConfigImpl;
	
	@Test
	public void testPrintFizzBuzz(){
		
		String result = fizzBuzzConfigImpl.getNumbers(15);
		System.out.println(result);
		assertEquals("'fizz buzz' ",result);
	}
	
	
	@Test
	public void testPrintFizz(){
		
		String result = fizzBuzzConfigImpl.getNumbers(6);
		System.out.println(result);
		assertEquals("'fizz'",result);
	}
	
	@Test
	public void testPrintBuzz(){
		
		String result = fizzBuzzConfigImpl.getNumbers(20);
		System.out.println(result);
		assertEquals("'buzz' ",result);
	}
	
}
