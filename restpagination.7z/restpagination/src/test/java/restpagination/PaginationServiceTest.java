package restpagination;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import com.rohit.rest.service.PaginationServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class PaginationServiceTest {

	@InjectMocks
	private PaginationServiceImpl paginationServiceImpl;

	@Test
	public void testPrintNumbers() {

		int start = 1;
		int size = 2;

		String result = paginationServiceImpl.getPages(1, 3);
		System.out.println(result);
		assertNotNull(result);

	}

}
