package com.aviva.rest.FizzBuzzSevice;

import static com.aviva.rest.FizzBuzzSevice.Constants.BUZZ;
import static com.aviva.rest.FizzBuzzSevice.Constants.COMMA_OPERATOR;
import static com.aviva.rest.FizzBuzzSevice.Constants.ERROR_MSG;
import static com.aviva.rest.FizzBuzzSevice.Constants.FIZZ;
import static com.aviva.rest.FizzBuzzSevice.Constants.FIZZ_AND_BUZZ;
import static com.aviva.rest.FizzBuzzSevice.Constants.NEXT_LINE;
import static com.aviva.rest.FizzBuzzSevice.Constants.WIZZ;
import static com.aviva.rest.FizzBuzzSevice.Constants.WIZZ_AND_WUZZ;
import static com.aviva.rest.FizzBuzzSevice.Constants.WUZZ;

import java.time.DayOfWeek;
import java.time.LocalDate;

import org.springframework.stereotype.Service;

@Service
public class FizzBuzzConfigImpl implements FizzBuzzConfig {

	@Override
	public String getNumbers(int endNumber) {

		StringBuilder sb = new StringBuilder();
		
		if (endNumber > 1 && endNumber < 1000) {
			
			// DayOfWeek is an enum representing the 7 days of the week -
			// Monday, Tuesday, Wednesday, Thursday, Friday, Saturday and // Sunday.
			// In addition to the textual enum name, each day-of-week has an // int value. from 1 (Monday) to 7 (Sunday).
			
			DayOfWeek dayOfWeek = DayOfWeek.from(LocalDate.now());
			
			
			if (endNumber % 3 == 0 && endNumber % 5 == 0) {

				if (dayOfWeek != null && dayOfWeek.getValue() == 3) {
					sb.append(WIZZ_AND_WUZZ);
				} else {
					sb.append(FIZZ_AND_BUZZ);
				}

			} else if (endNumber % 5 == 0) {

				if (dayOfWeek != null &&  dayOfWeek.getValue() == 3) {
					sb.append(WUZZ);
				} else {
					sb.append(BUZZ);
				}

			} else if (endNumber % 3 == 0) {

				if (dayOfWeek != null &&  dayOfWeek.getValue() == 3) {
					sb.append(WIZZ);
				} else {
					sb.append(FIZZ);
				}

			} else {
				for (int i = 2; i < endNumber; i++) {

					sb.append(i);
					if (i < (endNumber - 1)) {
						//sb.append(COMMA_OPERATOR);
						// To print Numbers in vertical order
						sb.append(NEXT_LINE);
					}
				}
			}

		}
		//Will send an error message in response if the given number is not in between 1 & 1000.
		else {
			sb.append(ERROR_MSG);
		}
		
		return sb.toString();
	}

}
