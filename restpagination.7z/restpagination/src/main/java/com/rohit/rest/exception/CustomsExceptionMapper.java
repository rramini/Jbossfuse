package com.rohit.rest.exception;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import org.apache.cxf.jaxrs.impl.WebApplicationExceptionMapper;

public class CustomsExceptionMapper extends WebApplicationExceptionMapper {

	@Override
	public Response toResponse(WebApplicationException ex) {
		System.out.println(ex.getMessage());
		return super.toResponse(ex);
	}
	
	
}
