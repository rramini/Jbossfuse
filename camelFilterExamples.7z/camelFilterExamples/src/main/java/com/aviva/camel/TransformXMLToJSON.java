package com.aviva.camel;

import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.model.dataformat.XmlJsonDataFormat;

public class TransformXMLToJSON {
	
	 public static void main(String[] args) throws Exception {
		 
	        CamelContext camelContext = new DefaultCamelContext();
	        try {
	        	camelContext.addRoutes(new RouteBuilder() {
					
					@Override
					public void configure() throws Exception {
						// TODO Auto-generated method stub
						  XmlJsonDataFormat xmlJsonFormat = new XmlJsonDataFormat();
					        xmlJsonFormat.setEncoding("UTF-8");
					        xmlJsonFormat.setForceTopLevelObject(true);
					//	from("file:D:/outputFolder/applicationContext.xml").convertBodyTo(JsonDataFormat.class).to(file:src/json");
						//from("file:D:/outputFolder/applicationContext.xml").marshal(xmlJsonFormat).to("file:src/json");
						//from("file:src/data?noop=true").marshal(xmlJsonFormat).to("file:src/json"); 
							from("file:D:/outputFolder").marshal(xmlJsonFormat).to("file:src/json");
						
					}
				});
	        	  camelContext.start();
	              Thread.sleep(2*60*1000 );
	        } finally {
	        	camelContext.stop();
	        }
		 
	 }

	
}
