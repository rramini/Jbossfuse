package com.rohit.rest.service;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;

import org.springframework.stereotype.Service;

import com.rohit.rest.exception.CustomException;

@Service
public class PaginationServiceImpl implements PaginationService {
//http://localhost:8080/restpagination/rest/pagination?start=0&size=10
	@Override
	public String getPages(int start, int size) {
		if(start < 0 || size <= 0) {
			exceptionHandler(new CustomException(500, "Invalid StartIndex or Page Size"));
		}
		
		StringBuilder sb = new StringBuilder();
		if(start != 0) {
			start = start * size;
		}
		
		for(int i= start; i <= (start+size -1 ); i++) {
			sb.append(i);
			if(i != (start+size -1)) {
				sb.append(", ");
			}
		}
		
		return sb.toString();
	}
	
	private  Response exceptionHandler(CustomException ex) {
		ResponseBuilder response = Response.status(Status.INTERNAL_SERVER_ERROR);
		response.type(MediaType.APPLICATION_XML);
		response.entity(ex.getMessage());
		throw new WebApplicationException(response.build());		
	}

}
