package com.aviva.rest.FizzBuzzSevice;

import static com.aviva.rest.FizzBuzzSevice.Constants.END_NUMBER;
import static com.aviva.rest.FizzBuzzSevice.Constants.FIZZ_BUZZ;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;


@Path(FIZZ_BUZZ)
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public interface FizzBuzzConfig {
	
//http://localhost:8282/FizzBuzz/rest/fizzbuzz?endNumber=1
	@GET
	public String getNumbers(@QueryParam(END_NUMBER) int endNumber);
	
}
