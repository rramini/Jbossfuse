package com.aviva.rest.FizzBuzzSevice;

public class Constants {

	public static final String FIZZ_BUZZ = "fizzbuzz";

	public static final String END_NUMBER = "endNumber";

	public static final String COMMA_OPERATOR = ", ";

	public static final String FIZZ = "'fizz'";

	public static final String BUZZ = "'buzz' ";

	public static final String FIZZ_AND_BUZZ = "'fizz buzz' ";
	
	public static final String NEXT_LINE = "\n";

	public static final String WIZZ = "'wizz'";

	public static final String WUZZ = "'wuzz' ";

	public static final String WIZZ_AND_WUZZ = "'wizz wuzz' ";

	public static final String ERROR_MSG = "Please enter a Valid Number between 1 and 1000";

}
