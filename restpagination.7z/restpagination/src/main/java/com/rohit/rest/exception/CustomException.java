package com.rohit.rest.exception;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CustomException extends Exception implements Serializable {

	private static final long serialVersionUID = 1L;
	private int error_code;
	private String details;
	public CustomException(int error_code, String details) {
		super();
		this.error_code = error_code;
		this.details = details;
	}
	public CustomException() {
		super();
	}
	public int getError_code() {
		return error_code;
	}
	public void setError_code(int error_code) {
		this.error_code = error_code;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	
	
}
